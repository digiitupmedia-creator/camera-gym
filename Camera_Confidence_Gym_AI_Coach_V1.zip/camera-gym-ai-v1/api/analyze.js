const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const MAX_B64 = 3_600_000;
const allowed = new Set(['video/webm','video/mp4','video/quicktime']);
const allowedOrigins = (process.env.ALLOWED_ORIGIN || '').split(',').map(s=>s.trim()).filter(Boolean);
function fail(res,code,message){return res.status(code).json({error:message});}
function parseJSON(s){const cleaned=String(s||'').replace(/^```(?:json)?\s*/,'').replace(/```\s*$/,'').trim();return JSON.parse(cleaned);}
module.exports = async function handler(req,res){
  res.setHeader('Cache-Control','no-store');
  res.setHeader('X-Content-Type-Options','nosniff');
  if(req.method!=='POST'){res.setHeader('Allow','POST');return fail(res,405,'POST required');}
  if(!process.env.GEMINI_API_KEY)return fail(res,503,'Gemini API key has not been configured on the server.');
  const origin=req.headers.origin;
  if(origin){let host;try{host=new URL(origin).host}catch{return fail(res,403,'Invalid origin');}
    const requestHost=(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
    if(host!==requestHost && !allowedOrigins.includes(origin))return fail(res,403,'Origin not allowed');
  }
  const {videoBase64,mimeType,prompt,skill,audience,attempt,firstAnalysis,consent}=req.body||{};
  if(consent!==true)return fail(res,400,'Explicit video-analysis consent is required.');
  if(!allowed.has(mimeType))return fail(res,400,'Unsupported recording format.');
  if(typeof videoBase64!=='string'||videoBase64.length<100||videoBase64.length>MAX_B64||!/^[a-zA-Z0-9+/=]+$/.test(videoBase64))return fail(res,413,'Recording too large or invalid. Try a shorter take.');
  if(typeof prompt!=='string'||prompt.length>1500||typeof skill!=='string'||skill.length>100||typeof audience!=='string'||audience.length>100)return fail(res,400,'Invalid mission context.');
  if(attempt!==1&&attempt!==2)return fail(res,400,'Invalid take number.');
  const earlier=attempt===2 && firstAnalysis && typeof firstAnalysis==='object' ? {
    main_point:firstAnalysis.main_point, top_correction:firstAnalysis.top_correction, dimensions:firstAnalysis.dimensions,
    evidence:firstAnalysis.evidence
  }:null;
  const instructions=`You are an evidence-based speaking coach for a founder selling healthcare operational services to doctors and clinic decision-makers. Evaluate a short camera-recorded answer, not attractiveness, inferred emotions, personality or eye-contact percentage. Speak to the speaker directly. Ground observations in actual spoken phrases, observable audio or video, and timestamp estimates ONLY when verifiable. Do not fabricate quotes or timestamps; if audio is unclear, say so. Do not treat normal hesitations or accents as defects. Do not award points for longer answers. Patient safety: do not offer medical advice. Consider the exact speaking mission and whether answer is relevant, audience-oriented and commercially sound. Don't assume marketing claims are true. Prioritise clarity, relevance, logical structure, conciseness, naturalness, and diagnostic questioning. Select ONE highest-impact practical correction. Every dimension score is an anchored 1-4 ordinal judgement, where 1=needs work, 2=developing, 3=clear, 4=strong. Don't make objective claims about emotions.\nMission: ${prompt}\nSkill: ${skill}\nAudience: ${audience}\nTake number: ${attempt}\nPrior take summary (only if second): ${JSON.stringify(earlier)}\nReturn ONLY a JSON object with this exact shape: {"main_point":"short summary or 'Unclear'","dimensions":{"clarity":1,"relevance":1,"structure":1,"conciseness":1,"listener_orientation":1},"evidence":[{"timestamp":"00:12 or null","observation":"specific grounded observation","quote":"exact short spoken quote or null"}],"top_correction":"one brief imperative","drill":"one concrete direction for next take","comparison":{"verdict":"improved|mixed|unchanged|insufficient_evidence|not_applicable","reason":"specific comparative observation"},"limitations":"short note about uncertainty or audio quality"}. 2-3 evidence items max. If this is take 1 comparison verdict is not_applicable. For take 2 compare ONLY against the supplied prior summary, not an unseen prior video; say so if evidence is insufficient. Never claim you watched both videos.`;
  const payload={contents:[{role:'user',parts:[{text:instructions},{inlineData:{mimeType,data:videoBase64}}]}],generationConfig:{responseMimeType:'application/json',temperature:0.15,maxOutputTokens:1300}};
  try{
    const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),55000);
    let response;
    try{response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':process.env.GEMINI_API_KEY},body:JSON.stringify(payload),signal:controller.signal});}
    finally{clearTimeout(timeout);}
    const body=await response.json().catch(()=>({}));
    if(!response.ok){return fail(res,502,body?.error?.message?.slice(0,230)||'Gemini analysis failed.');}
    const raw=(body.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('');
    let analysis;try{analysis=parseJSON(raw);}catch{return fail(res,502,'AI returned a response that could not be read. Please retry.');}
    if(!analysis||typeof analysis.top_correction!=='string'||!analysis.dimensions)return fail(res,502,'Incomplete AI analysis. Please retry.');
    return res.status(200).json({analysis,model:MODEL,comparisonBasis:attempt===2?'first-take analysis summary':'single recording'});
  }catch(err){return fail(res,504,err.name==='AbortError'?'AI analysis timed out. Please retry.':'Unable to complete AI analysis right now.');}
};
